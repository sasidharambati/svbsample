import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class ApisService {

  constructor(private http: HttpClient) { }
   baseUrl = 'http://localhost:3000/';

  getTableGridUrl() {
    return this.http.get(this.baseUrl + 'users');
  }
}

