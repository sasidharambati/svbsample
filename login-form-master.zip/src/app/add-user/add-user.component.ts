import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'cf-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.scss']
})
export class AddUserComponent implements OnInit {
  addUserForm: FormGroup;
  constructor(private fb: FormBuilder) { }

  ngOnInit() {
    this.addUserForm = this.fb.group({
      fristName: ['', [Validators.required, Validators.minLength(3), Validators.pattern('^[\\sa-zA-Z.]*$')]],
      lastName: ['', [Validators.required, Validators.minLength(3), Validators.pattern('^[\\sa-z.]*$')]],
      contact: ['', [Validators.required]],
      personalEmail1 : ['', [Validators.required, Validators.pattern('^[[a-zA-Z]+[.]+[a-zA-Z]{2,3}]*$')]],
      altEmail: ['', [Validators.required, Validators.pattern('^[[a-zA-Z]+[.]+[a-zA-Z]{2,3}]*$')]],
      address: ['', [Validators.required]],
      address2: ['', [Validators.required]],
      cite: ['', [Validators.required]],
      pincode: ['', [Validators.required,Validators.pattern('^[\\s0-9.]*$')]],
      company: ['', [Validators.required]],
      role: ['', [Validators.required,Validators.minLength(3)]],
      ctc: ['', [Validators.required, Validators.pattern('^[\\s0-9.]*$')]],
      username: ['']

    });
  }
  onSubmit() {
    // console.log("data",this.addUserForm.value)
    if (this.addUserForm.invalid) {
      console.log('validation required fields');
      const controls = this.addUserForm.controls;
      Object.keys(controls).forEach(key => {
        controls[key].markAsTouched();
      });
    }
  }
}
